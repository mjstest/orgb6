# store
https://morejust.github.io/store

Store unlimited files in your github.

Yes! We were banned by GitHub. Follow our next projects on: [https://morejust.foundation](https://morejust.foundation)

[<img src="https://raw.githubusercontent.com/morejust/foundation/master/madebymorejust.png" width="100">](https://morejust.foundation/?from=morejust.store)
